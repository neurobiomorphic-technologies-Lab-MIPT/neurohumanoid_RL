# AAWR seminar slides

Откройте `main.tex` в Overleaf и выберите компилятор **XeLaTeX**.

Файлы в папке `figures/` - вырезанные иллюстрации из статьи Hu et al., *Real-World Reinforcement Learning of Active Perception Behaviors*.
